#!/bin/bash
source /usr/src/app/venv/bin/activate && python /usr/src/app/manage.py crawl